```javascript
/* =========================================================
   NKP | DASHBOARD JAVASCRIPT
   Namma KanakkuPillai
   ========================================================= */


/* =========================================================
   LOGIN CHECK
   ========================================================= */

const loggedIn = localStorage.getItem("loggedIn");

if (loggedIn !== "true") {
    window.location.href = "login.html";
}


/* =========================================================
   ELEMENTS
   ========================================================= */

const userNameElement = document.getElementById("userName");
const profileAvatar = document.getElementById("profileAvatar");

const businessNameElement = document.getElementById("businessName");
const industryElement = document.getElementById("industry");
const employeesElement = document.getElementById("employees");
const locationElement = document.getElementById("businessLocation");

const startAssessmentBtn =
    document.getElementById("startAssessmentBtn");

const activityStartBtn =
    document.getElementById("activityStartBtn");

const logoutBtn =
    document.getElementById("logoutBtn");

const assessmentNav =
    document.getElementById("assessmentNav");


/* =========================================================
   LOAD USER DATA
   ========================================================= */

const savedUserName =
    localStorage.getItem("userName");

if (savedUserName) {

    userNameElement.textContent = savedUserName;

    profileAvatar.textContent =
        savedUserName.charAt(0).toUpperCase();

} else {

    userNameElement.textContent = "User";

    profileAvatar.textContent = "U";
}


/* =========================================================
   LOAD BUSINESS DATA
   ========================================================= */

const savedBusinessName =
    localStorage.getItem("businessName");

const savedIndustry =
    localStorage.getItem("industry");

const savedEmployees =
    localStorage.getItem("employees");

const savedLocation =
    localStorage.getItem("businessLocation");


businessNameElement.textContent =
    savedBusinessName || "Your Business";

industryElement.textContent =
    savedIndustry || "Not specified";

employeesElement.textContent =
    savedEmployees || "—";

locationElement.textContent =
    savedLocation || "Not specified";


/* =========================================================
   START / OPEN ASSESSMENT
   ========================================================= */

function openAssessment() {

    /*
       IMPORTANT:
       Do NOT delete assessmentAnswers here.

       This allows the user to continue an assessment
       if they return to the dashboard.
    */

    window.location.href = "categories.html";
}


/* =========================================================
   START NEW ASSESSMENT
   ========================================================= */

function startNewAssessment() {

    const existingAnswers =
        localStorage.getItem("assessmentAnswers");

    if (existingAnswers) {

        const continueExisting =
            confirm(
                "You already have assessment progress.\n\n" +
                "Click OK to continue your assessment.\n" +
                "Click Cancel to start a new assessment."
            );

        if (continueExisting) {

            openAssessment();

            return;
        }
    }

    /*
       Start completely new assessment
    */

    localStorage.removeItem("startCategory");
    localStorage.removeItem("selectedSubCategory");
    localStorage.removeItem("assessmentAnswers");
    localStorage.removeItem("assessmentScore");

    localStorage.removeItem("categoryResults");
    localStorage.removeItem("completedCategories");

    window.location.href = "categories.html";
}


/* =========================================================
   START ASSESSMENT BUTTON
   ========================================================= */

if (startAssessmentBtn) {

    startAssessmentBtn.addEventListener(
        "click",
        function () {

            startNewAssessment();

        }
    );

}


/* =========================================================
   ACTIVITY START BUTTON
   ========================================================= */

if (activityStartBtn) {

    activityStartBtn.addEventListener(
        "click",
        function () {

            startNewAssessment();

        }
    );

}


/* =========================================================
   ASSESSMENT NAVIGATION
   ========================================================= */

if (assessmentNav) {

    assessmentNav.addEventListener(
        "click",
        function (event) {

            event.preventDefault();

            openAssessment();

        }
    );

}


/* =========================================================
   HEALTH AREA CARDS
   ========================================================= */

const healthCards =
    document.querySelectorAll(".health-card");


healthCards.forEach(function (card) {

    card.addEventListener(
        "click",
        function () {

            const category =
                card.dataset.category;

            if (!category) {

                console.warn(
                    "Category not found for this card."
                );

                return;
            }


            /*
               Save selected category
            */

            localStorage.setItem(
                "startCategory",
                category
            );


            /*
               Clear old selected subcategory
            */

            localStorage.removeItem(
                "selectedSubCategory"
            );


            /*
               Open subcategory page
            */

            window.location.href =
                "subcategories.html";

        }
    );

});


/* =========================================================
   REPORTS BUTTON
   ========================================================= */

const reportNavItems =
    document.querySelectorAll(
        ".sidebar-nav .nav-item"
    );


reportNavItems.forEach(function (item) {

    const text =
        item.innerText.trim().toLowerCase();


    if (text === "reports") {

        item.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                window.location.href =
                    "reports.html";

            }
        );

    }

});


/* =========================================================
   AI INSIGHTS BUTTON
   ========================================================= */

reportNavItems.forEach(function (item) {

    const text =
        item.innerText.trim().toLowerCase();


    if (text === "ai insights") {

        item.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                window.location.href =
                    "ai-insights.html";

            }
        );

    }

});


/* =========================================================
   SETTINGS BUTTON
   ========================================================= */

reportNavItems.forEach(function (item) {

    const text =
        item.innerText.trim().toLowerCase();


    if (text === "settings") {

        item.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                /*
                   Business setup currently acts as
                   the business information/settings page.
                */

                window.location.href =
                    "business-setup.html";

            }
        );

    }

});


/* =========================================================
   VIEW DETAILS BUTTON
   ========================================================= */

const viewDetailsButtons =
    document.querySelectorAll(".view-details");


viewDetailsButtons.forEach(function (button, index) {

    button.addEventListener(
        "click",
        function () {

            /*
               First View Details button
               = Business Details
            */

            if (index === 0) {

                window.location.href =
                    "business-setup.html";

                return;
            }


            /*
               Second View All button
               = Reports / Assessment History
            */

            if (index === 1) {

                window.location.href =
                    "reports.html";

                return;
            }

        }
    );

});


/* =========================================================
   VIEW GUIDE BUTTON
   ========================================================= */

const secondaryButtons =
    document.querySelectorAll(
        ".secondary-btn"
    );


secondaryButtons.forEach(function (button) {

    button.addEventListener(
        "click",
        function () {

            alert(
                "NKP Assessment Guide\n\n" +

                "1. Select a business health category.\n" +

                "2. Choose a subcategory.\n" +

                "3. Answer 5 questions in each subcategory.\n" +

                "4. Complete 25 questions in each category.\n" +

                "5. View your category result.\n" +

                "6. Continue with the remaining categories.\n\n" +

                "After all 5 categories are completed, " +
                "NKP will generate your final assessment " +
                "and AI-powered business recommendations."
            );

        }
    );

});


/* =========================================================
   PROFILE CLICK
   ========================================================= */

const profile =
    document.querySelector(".profile");


if (profile) {

    profile.addEventListener(
        "click",
        function () {

            /*
               Currently open Business Setup
               for profile/business information.
            */

            window.location.href =
                "business-setup.html";

        }
    );

}


/* =========================================================
   NOTIFICATION BUTTON
   ========================================================= */

const notificationBtn =
    document.querySelector(".notification-btn");


if (notificationBtn) {

    notificationBtn.addEventListener(
        "click",
        function () {

            alert(
                "No new notifications."
            );

        }
    );

}


/* =========================================================
   MOBILE MENU
   ========================================================= */

const mobileMenu =
    document.querySelector(".mobile-menu");

const sidebar =
    document.querySelector(".sidebar");


if (mobileMenu && sidebar) {

    mobileMenu.addEventListener(
        "click",
        function () {

            sidebar.classList.toggle(
                "mobile-open"
            );

        }
    );

}


/* =========================================================
   LOGOUT
   ========================================================= */

if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        function (event) {

            event.preventDefault();


            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (!confirmLogout) {

                return;

            }


            /*
               Remove login/session information
            */

            localStorage.removeItem(
                "loggedIn"
            );

            localStorage.removeItem(
                "userEmail"
            );

            localStorage.removeItem(
                "userName"
            );

            localStorage.removeItem(
                "userPhone"
            );

            localStorage.removeItem(
                "userId"
            );


            /*
               Redirect to login
            */

            window.location.href =
                "login.html";

        }
    );

}


/* =========================================================
   PAGE LOAD MESSAGE
   ========================================================= */

console.log(
    "NKP Dashboard loaded successfully."
);
```
