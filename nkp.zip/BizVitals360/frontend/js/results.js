/* =========================================================
   NKP | RESULTS PAGE
   ========================================================= */


/* =========================================================
   GET SCORE
   ========================================================= */

const scoreValue =
    document.getElementById("scoreValue");

const circleScore =
    document.getElementById("circleScore");

const scoreMessage =
    document.getElementById("scoreMessage");

const scoreCircle =
    document.querySelector(".score-circle");


/* =========================================================
   READ SCORE FROM LOCAL STORAGE
   ========================================================= */

let score =
    Number(
        localStorage.getItem(
            "assessmentScore"
        )
    );


/* =========================================================
   CHECK SCORE
   ========================================================= */

if (
    isNaN(score)
) {

    score = 0;

}


/* Keep score between 0 and 100 */

score =
    Math.max(
        0,
        Math.min(
            100,
            score
        )
    );


/* =========================================================
   DISPLAY SCORE
   ========================================================= */

scoreValue.textContent =
    score;


circleScore.textContent =
    `${score}%`;


/* =========================================================
   SCORE MESSAGE
   ========================================================= */

if (score >= 80) {

    scoreMessage.textContent =
        "Excellent! Your business shows strong overall health and good growth readiness.";

}
else if (score >= 60) {

    scoreMessage.textContent =
        "Good progress! Your business is performing well, with some areas that can be improved.";

}
else if (score >= 40) {

    scoreMessage.textContent =
        "Your business has a developing foundation. Several areas need focused improvement.";

}
else {

    scoreMessage.textContent =
        "Your business needs attention in several important areas. Start with the highest-priority improvements.";

}


/* =========================================================
   UPDATE SCORE CIRCLE
   ========================================================= */

const degrees =
    score * 3.6;


scoreCircle.style.background =
    `conic-gradient(
        #16A34A 0deg,
        #16A34A ${degrees}deg,
        #E2E8F0 ${degrees}deg,
        #E2E8F0 360deg
    )`;


/* =========================================================
   AI BUTTON
   ========================================================= */

const aiButton =
    document.getElementById(
        "aiSuggestionsButton"
    );


if (aiButton) {

    aiButton.addEventListener(
        "click",
        function () {

            /*
             * The AI page will read:
             *
             * assessmentScore
             * assessmentAnswers
             * assessmentComplete
             *
             * from localStorage.
             */

            localStorage.setItem(
                "aiAnalysisRequested",
                "true"
            );

        }
    );

}


/* =========================================================
   DEBUG
   ========================================================= */

console.log(
    "NKP Results Page Loaded"
);

console.log(
    "Final Assessment Score:",
    score
);

console.log(
    "Assessment Complete:",
    localStorage.getItem(
        "assessmentComplete"
    )
);